export function getSuggestion(mood) {
  switch (mood) {
    case "😊":
      return "Keep up the good vibes! Try journaling about what made you happy.";
    case "😐":
      return "Feeling meh? Take a short walk or drink water. You got this!";
    case "😢":
      return "It's okay to feel sad. Try a 5-min breathing exercise or write it out.";
    case "😡":
      return "Try deep breathing or punching a pillow 😤. Release the anger safely.";
    case "😴":
      return "Get some rest. Your body and mind need it.";
    default:
      return "Check in with yourself. You matter.";
  }
}
