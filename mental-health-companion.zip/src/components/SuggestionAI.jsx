import React from 'react';
import { getSuggestion } from '../../ai/suggestionEngine';

const SuggestionAI = ({ mood }) => {
  if (!mood) return null;

  return (
    <div className="p-4 mt-4 bg-green-100 rounded-xl shadow">
      <h3 className="font-semibold">Your Suggestion:</h3>
      <p>{getSuggestion(mood)}</p>
    </div>
  );
};

export default SuggestionAI;
