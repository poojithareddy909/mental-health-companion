import React from 'react';

const MoodTracker = ({ onMoodSelect }) => {
  const moods = ["😊", "😐", "😢", "😡", "😴"];

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-2">How are you feeling today?</h2>
      <div className="flex gap-4">
        {moods.map((mood, index) => (
          <button
            key={index}
            className="text-3xl"
            onClick={() => onMoodSelect(mood)}
          >
            {mood}
          </button>
        ))}
      </div>
    </div>
  );
};

export default MoodTracker;
