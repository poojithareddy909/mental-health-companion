import React, { useState } from 'react';
import MoodTracker from './components/MoodTracker';
import SuggestionAI from './components/SuggestionAI';

function App() {
  const [mood, setMood] = useState(null);

  return (
    <div className="max-w-lg mx-auto mt-10">
      <MoodTracker onMoodSelect={setMood} />
      <SuggestionAI mood={mood} />
    </div>
  );
}

export default App;
