# MindMate – Your Mental Health Companion 💖

A simple, privacy-first mental health app to help users track mood, reduce stress, and get AI-based self-care suggestions.

## 🔧 Features
- Daily mood check-ins
- AI-driven activity suggestions
- Anonymous peer support (planned)
- Self-care goals and planner
- Firebase backend

## 🛠️ Tech Stack
- React + Tailwind CSS
- Firebase (Auth, Firestore)
- AI logic using JS
- Optional: Google Fit API

## 🚀 Run Locally

```bash
npm install
npm start
```

## 🤝 Contributing
PRs welcome! Mental health matters 💚
